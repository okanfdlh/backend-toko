module.exports = require('./dist/cleave-react-node.js');
