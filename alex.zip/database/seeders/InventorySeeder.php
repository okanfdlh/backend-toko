<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class InventorySeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run()
    {
        // DB::table('inventories')->insert([
        //     [
        //         'name' => 'barang 1',
        //         'stock' => 10,
        //         'unit' => 'pcs',
        //     ],
        // ]);
    }
}
